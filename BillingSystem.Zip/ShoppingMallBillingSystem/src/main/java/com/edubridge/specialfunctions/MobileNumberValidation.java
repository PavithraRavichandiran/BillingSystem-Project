package com.edubridge.specialfunctions;
//package com.edubridge.SpecialFunctions;

/*
 * import java.util.regex.Pattern;
 * 
 * import javax.validation.ConstraintValidator; import
 * javax.validation.ConstraintValidatorContext;
 * 
 * public class MobileNumberValidation implements ConstraintValidator<
 * MobileNumberValidator,String> { private final String PATTERN =" [0-9]{10}";
 * 
 * @Override public boolean isValid(String value, ConstraintValidatorContext
 * context) { if(Pattern.matches(PATTERN, mobileNo)) { return true; } return
 * false; } }
 */